package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class restServer {
	@RequestMapping("/hash")
	public String generateHash() {
		String data = "Trent Hesler";
		try {
			MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
			byte[] checksum = messageDigest.digest(data.getBytes(StandardCharsets.UTF_8));
			
			//Convert bytes to hex
			String bytesToHex = new String();
			for (byte b: checksum) {
				bytesToHex += String.format("%02x", b);
			}
			
			//Output the result
			return "Data: " + data + ", Cipher: SHA-256, Checksum: " + bytesToHex;
		} catch (NoSuchAlgorithmException err) {
			err.printStackTrace();
			return "ERROR!";
		}
	}
}